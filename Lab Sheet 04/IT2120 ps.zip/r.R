setwd("C:\\Users\\IT24100651\\Desktop\\IT24100651")

# 1. question
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")  # Adjust sep if necessary

# Check the column names to verify the data
colnames(branch_data)

# 2. question
# Display the structure of the dataset (data types of variables)
str(branch_data)

# Explanation of the scales of measurement (based on column names in your dataset):
# - Branch: Factor (Nominal)
# - Sales_X1: Numeric (Ratio)
# - Advertising_X2: Numeric (Ratio)
# - Years_X3: Numeric (Ratio)

# 3. question
# Create a boxplot for the Sales_X1 variable
boxplot(branch_data$Sales_X1, 
        main = "Boxplot of Sales_X1", 
        horizontal = TRUE, 
        outline = FALSE, 
        col = "lightblue", 
        ylab = "Sales")

# Interpretation:
# - The boxplot will show the distribution of Sales_X1, with the median, quartiles, and any potential outliers.
# - "Outline = FALSE" ensures that outliers are not plotted as individual points.
# - The boxplot will help identify the symmetry, skewness, and the presence of any outliers.

# 4. question
# Five-number summary for Advertising_X2
summary(branch_data$Advertising_X2)

# Calculate the Interquartile Range (IQR) for Advertising_X2
IQR(branch_data$Advertising_X2)

# The five-number summary includes the min, Q1 (first quartile), median, Q3 (third quartile), and max.
# IQR = Q3 - Q1 is a measure of spread or variability.

# 5. Write an R function to find the outliers in a numeric vector and check for outliers in the Years_X3 variable

# Define the function to find outliers using the IQR method
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)  # First quartile
  Q3 <- quantile(x, 0.75)  # Third quartile
  IQR_value <- IQR(x)      # Interquartile range
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]  # Find outliers
  return(outliers)
}

# Check for outliers in the Years_X3 variable
outliers_in_years <- find_outliers(branch_data$Years_X3)

# Print the outliers in Years_X3
print(outliers_in_years)

# 6. Additional information if needed:
# Use `head(branch_data)` to see the first few rows of the data
# Use `str(branch_data)` to view the structure and data types
