setwd("C://Users//IT24100651//Desktop//IT24100651")
# Weights data
weights <- c(2.46, 2.45, 2.47, 2.71, 2.46, 2.05, 2.6, 2.42, 2.43, 2.53, 2.57, 2.85, 
             2.7, 2.53, 2.28, 2.2, 2.57, 2.89, 2.51, 2.47, 2.66, 2.06, 2.41, 2.65, 
             2.76, 2.43, 2.61, 2.57, 2.73, 2.17, 2.67, 2.05, 1.71, 2.32, 2.23, 2.76, 
             2.7, 2.13, 2.75, 2.2)

# Nicotine data
nicotine <- c(1.09, 1.74, 1.58, 2.11, 1.64, 1.79, 1.37, 1.75, 1.92, 1.47, 2.03, 
              1.86, 0.72, 2.46, 1.93, 1.63, 2.31, 1.97, 1.7, 1.9, 1.69, 1.88, 1.4, 
              2.37, 1.79, 0.85, 2.17, 1.68, 1.85, 2.08, 1.64, 1.75, 2.28, 1.24, 
              2.55, 1.51, 1.82, 1.67, 2.09, 1.69)

# Population mean
mean_weight <- mean(weights)
mean_nicotine <- mean(nicotine)

# Population variance
var_weight <- var(weights)
var_nicotine <- var(nicotine)

# Output the results
mean_weight
mean_nicotine
var_weight
var_nicotine




# Your weights vector
weights <- c(2.46, 2.45, 2.47, 2.71, 2.46, 2.05, 2.6, 2.42, 2.43, 2.53, 2.57, 2.85, 
             2.7, 2.53, 2.28, 2.2, 2.57, 2.89, 2.51, 2.47, 2.66, 2.06, 2.41, 2.65, 
             2.76, 2.43, 2.61, 2.57, 2.73, 2.17, 2.67, 2.05, 1.71, 2.32, 2.23, 2.76, 
             2.7, 2.13, 2.75, 2.2)

# Set the number of samples and sample size
num_samples <- 25
sample_size <- 6

# Create vectors to store sample means and sample standard deviations
sample_means <- numeric(num_samples)
sample_sds <- numeric(num_samples)

set.seed(123)  # For reproducibility

for(i in 1:num_samples){
  # Draw sample with replacement
  sample_data <- sample(weights, sample_size, replace = TRUE)
  
  # Calculate sample mean and sd
  sample_means[i] <- mean(sample_data)
  sample_sds[i] <- sd(sample_data)
}

# Calculate mean and standard deviation of the sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

# Population mean and standard deviation
pop_mean <- mean(weights)
pop_sd <- sd(weights)

# Output the results
cat("Population Mean:", pop_mean, "\n")
cat("Population SD:", pop_sd, "\n\n")

cat("Mean of Sample Means:", mean_of_sample_means, "\n")
cat("SD of Sample Means:", sd_of_sample_means, "\n")
